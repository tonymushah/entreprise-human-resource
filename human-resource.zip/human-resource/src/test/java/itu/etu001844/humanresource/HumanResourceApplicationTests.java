package itu.etu001844.humanresource;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HumanResourceApplicationTests {

	@Test
	void contextLoads() {
	}

}
